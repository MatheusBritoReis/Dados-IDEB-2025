/*
 * Recupera coordenadas ausentes das escolas usando a camada georreferenciada
 * do Catálogo de Escolas do INEP publicada no ArcGIS.
 * Fonte do serviço: https://services3.arcgis.com/ba17q0p2zHwzRK3B/ArcGIS/rest/services/inep_escolas_fmt_250609_geocode/FeatureServer/1
 * A camada informa o código INEP e a geometria das escolas. As coordenadas
 * são associadas pelo código INEP, nunca apenas pelo nome.
 */
(function () {
    'use strict';

    var MISSING_INEP_CODES = new Set([
    50000136,
    50001574,
    50003887,
    50005790,
    50005898,
    50005960,
    50006150,
    50006401,
    50006487,
    50007521,
    50009257,
    50009680,
    50009915,
    50011367,
    50011375,
    50011430,
    50013360,
    50014480,
    50014684,
    50014706,
    50014714,
    50014749,
    50014854,
    50015494,
    50015931,
    50017110,
    50017128,
    50017403,
    50018124,
    50018434,
    50020056,
    50020781,
    50021362,
    50022342,
    50023527,
    50024779,
    50025007,
    50025732,
    50029827,
    50030426,
    50034251,
    50034790,
    50034910,
    50034936,
    50034944,
    50035061,
    50035592,
    50035908,
    50035983,
    50036246,
    50036351,
    50036467,
    50040600,
    50042408
    ].map(String));

    var ENDPOINT = 'https://services3.arcgis.com/ba17q0p2zHwzRK3B/ArcGIS/rest/services/inep_escolas_fmt_250609_geocode/FeatureServer/1/query';
    var PAGE_SIZE = 2000;

    function codeOf(v) {
        if (v === null || v === undefined) return '';
        return String(Math.round(Number(v)));
    }

    function getSchoolCode(attributes) {
        return codeOf(attributes['Código_INEP'] !== undefined
            ? attributes['Código_INEP']
            : attributes.Codigo_INEP);
    }

    async function loadPage(offset) {
        var params = new URLSearchParams({
            where: "UF='MS'",
            outFields: 'Código_INEP,Latitude,Longitude,Escola,Município',
            returnGeometry: 'true',
            outSR: '4326',
            f: 'json',
            resultOffset: String(offset),
            resultRecordCount: String(PAGE_SIZE),
            orderByFields: 'Código_INEP'
        });
        var response = await fetch(ENDPOINT + '?' + params.toString(), {
            method: 'GET',
            mode: 'cors',
            credentials: 'omit'
        });
        if (!response.ok) throw new Error('Serviço de coordenadas respondeu HTTP ' + response.status);
        var data = await response.json();
        if (data.error) throw new Error(data.error.message || 'Erro no serviço de coordenadas');
        return data;
    }

    async function recover() {
        if (typeof jsonSource_Escolas_IDEB_2025 === 'undefined' ||
            typeof ol === 'undefined' || typeof ol.geom === 'undefined') return;

        var missingFeatures = jsonSource_Escolas_IDEB_2025.getFeatures().filter(function (feature) {
            var geometry = feature.getGeometry();
            var code = codeOf(feature.get('ID_ESCOLA'));
            return MISSING_INEP_CODES.has(code) && (!geometry || !geometry.getCoordinates());
        });
        if (!missingFeatures.length) return;

        var byCode = new Map();
        missingFeatures.forEach(function (feature) {
            var code = codeOf(feature.get('ID_ESCOLA'));
            if (!byCode.has(code)) byCode.set(code, []);
            byCode.get(code).push(feature);
        });

        var recovered = new Set();
        var offset = 0;
        var keepPaging = true;

        while (keepPaging && recovered.size < byCode.size) {
            var data = await loadPage(offset);
            var rows = Array.isArray(data.features) ? data.features : [];
            rows.forEach(function (row) {
                var attrs = row.attributes || {};
                var code = getSchoolCode(attrs);
                if (!byCode.has(code) || recovered.has(code)) return;

                var x, y;
                if (row.geometry && Number.isFinite(Number(row.geometry.x)) && Number.isFinite(Number(row.geometry.y))) {
                    x = Number(row.geometry.x);
                    y = Number(row.geometry.y);
                } else if (Number.isFinite(Number(attrs.Longitude)) && Number.isFinite(Number(attrs.Latitude))) {
                    x = Number(attrs.Longitude);
                    y = Number(attrs.Latitude);
                } else {
                    return;
                }
                if (!Number.isFinite(x) || !Number.isFinite(y) || x === 0 || y === 0) return;

                var point = new ol.geom.Point(ol.proj.transform([x, y], 'EPSG:4326', 'EPSG:3857'));
                byCode.get(code).forEach(function (feature) { feature.setGeometry(point.clone()); });
                recovered.add(code);
            });

            keepPaging = data.exceededTransferLimit === true || rows.length === PAGE_SIZE;
            offset += rows.length;
            if (!rows.length) keepPaging = false;
        }

        jsonSource_Escolas_IDEB_2025.changed();
        if (typeof applyStyles === 'function') applyStyles();
        if (typeof map !== 'undefined' && map && typeof map.render === 'function') map.render();

        var unresolved = Array.from(byCode.keys()).filter(function (code) { return !recovered.has(code); });
        console.info('[Coordenadas INEP] Recuperadas ' + recovered.size + ' de ' + byCode.size + ' escolas com geometria ausente.');
        if (unresolved.length) console.warn('[Coordenadas INEP] Códigos ainda sem coordenadas na fonte: ' + unresolved.join(', '));
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { recover().catch(function (err) { console.warn('[Coordenadas INEP] Não foi possível recuperar coordenadas automaticamente:', err); }); });
    } else {
        recover().catch(function (err) { console.warn('[Coordenadas INEP] Não foi possível recuperar coordenadas automaticamente:', err); });
    }
})();
